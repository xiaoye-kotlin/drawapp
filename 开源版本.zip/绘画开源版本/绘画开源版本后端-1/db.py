from index import db
db.create_all()