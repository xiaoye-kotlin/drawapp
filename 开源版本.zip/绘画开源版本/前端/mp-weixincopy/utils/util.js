
//获取openid方法
function getopenid() {
  return new Promise(function (resolve, reject) {
    wx.getSetting({
      success: function (res) {
          //跳出等待提示标签
          wx.showLoading({
            title: '加载中',
            mask: true
          })
          //获取openid
          wx.login({
            success: function (res_login) {
              if (res_login.code) {
                    var code = res_login.code;
                    wx.request({
                      url: 'https://www.wanfankeji19.xyz/copynew/public/api/wanfanai/getopenid',
                      method: 'POST',
                      header: {// 设置请求的 header  
                        'content-type': 'application/x-www-form-urlencoded'
                      },
                      data: {
                        appid:1,
                        code,
                      },
                      success: function (res) {
                        wx.hideLoading()
                        getApp().globalData.openid = res.data.openid
                        if (res.errMsg == 'request:ok') {
                          var res = {
                            "openid": res.data.openid,
                          }
                          resolve(res)
                          wx.request({
                            url: 'https://www.wanfankeji19.xyz/copynew/public/api/wanfanai/register',
                            method: 'POST',
                            header: {// 设置请求的 header  
                              'content-type': 'application/x-www-form-urlencoded'
                            },
                            data: {
                              appid:1,
                              openid: res.openid,
                            },
                            success: function (res) {
                              getApp().globalData.userid=res.data
                            },
                            fail: function (res) {
                            }
                          })
                        } else {
                          wx.showToast({
                            title: '登录失败~',
                          })
                        }
                      },
                      fail: function (res) {
                        wx.showToast({
                          title: '请求失败',
                        })
                      },
                    })
              }
            }
          })
      }
    })
  })
}


module.exports = {
  getopenid: getopenid,//获取openid接口
}