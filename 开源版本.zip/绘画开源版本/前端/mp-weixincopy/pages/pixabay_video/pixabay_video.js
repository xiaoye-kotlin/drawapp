// pages/myinfo/myinfo.js
var util = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    total:0,
    page:1,
    text:'',
    hits:''
  },

  //加
  addnow:function(e){
        var that = this
        var zong = Math.ceil(that.data.total/5)
        console.log(zong);
        if(that.data.page == zong){
            wx.showToast({
                title: '没有更多了...',
                icon: 'none',
                duration: 2000
              })
              return
        }
        that.setData({
            page: that.data.page+1
        })
        that.submit()
  },

  //减
  delnow:function(e){
    var that = this
    if(that.data.page == 1){
        wx.showToast({
            title: '已经在第一页了...',
            icon: 'none',
            duration: 2000
          })
          return
    }
    that.setData({
        page: that.data.page-1
    })
    that.submit()

},


  //复制openid
  copynow:function(e){
    wx.setClipboardData({
        data: e.currentTarget.dataset.text,
        success: function (res) {
          wx.getClipboardData({
            success: function (res) {
              wx.showToast({
                title: '复制成功',
                icon: 'none',
                duration: 2000
             })
            }
          })
        }
      })
  },



  //输入要求
  settext: function (e) {
    this.setData({
        text: e.detail.value
    })
  },

  //保存视频到相册
  baocun:function(e){
      console.log(e.currentTarget.dataset.img);
      wx.downloadFile({
        url: e.currentTarget.dataset.img,
        success: function (res) {
          wx.saveImageToPhotosAlbum({
            filePath: res.tempFilePath,
            success: function () {
              wx.showToast({
                title: '保存成功'
              })
            },
            fail: function () {
              wx.showToast({
                title: '保存失败',
                icon: 'none'
              })
            }
          })
        }
      })
    },

  //查询
  submit:function(){
    if (this.data.text == "" ){
      wx.showToast({
        title: '请输入要求',
        icon:'none'
      })
      return
    }
    var that = this
    wx.showLoading({
        title: '生成中...',
      })
    wx.request({
      url: 'https://www.wanfankeji19.xyz/copynew/public/api/wanfanai/getvideopixabay',
      method: 'POST',
      header: {// 设置请求的 header  
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        text:that.data.text,
        page:that.data.page
      },
      success: function (res) {
        wx.hideLoading()
        if(res.data.total==0){
            wx.showToast({
                title: '正在学习此类视频...',
                icon: 'none',
                duration: 2000
            })
        }else{
            that.setData({
                hits:res.data.hits,
                total:res.data.total
            })
            var imgarr = []
            for (var i = 0; i < res.data.hits.length; i++) {
                imgarr.push(res.data.hits[i]['largeImageURL'])
              }
              that.setData({
                imgarr:imgarr
            })
        }
      },
      fail: function (res) {
        wx.showToast({
          title: '请求失败',
        })
      },
    })
  },

  //查询
  submit_dian:function(){
    if (this.data.text == "" ){
      wx.showToast({
        title: '请输入要求',
        icon:'none'
      })
      return
    }
    var that = this
    wx.showLoading({
        title: '生成中...',
      })
    wx.request({
      url: 'https://www.wanfankeji19.xyz/copynew/public/api/wanfanai/getvideopixabay',
      method: 'POST',
      header: {// 设置请求的 header  
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        text:that.data.text,
        page:1
      },
      success: function (res) {
        wx.hideLoading()
        if(res.data.total==0){
            wx.showToast({
                title: '正在学习此类视频...',
                icon: 'none',
                duration: 2000
            })
        }else{
            that.setData({
                hits:res.data.hits,
                total:res.data.total
            })
            var imgarr = []
            for (var i = 0; i < res.data.hits.length; i++) {
                imgarr.push(res.data.hits[i]['largeImageURL'])
              }
              that.setData({
                imgarr:imgarr
            })
        }
      },
      fail: function (res) {
        wx.showToast({
          title: '请求失败',
        })
      },
    })
  },


  //点击查看视频
  previewImage: function (e) {
    var that = this
    var imgArr = that.data.imgarr;
    var index = e.currentTarget.dataset.index;
    console.log(imgArr);
    console.log(index);
    wx.previewImage({
      current: imgArr[index], // 当前显示视频的http链接
      urls: imgArr // 需要预览的视频http链接列表
    })
  },





  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
})