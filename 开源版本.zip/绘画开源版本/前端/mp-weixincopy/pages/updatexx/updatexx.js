// pages/myinfo/myinfo.js
var util = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
      name:'',
      tel:'',
      avatarurl:'',
      nickname:'',
      fileList: [],
  },

  //复制openid
  copynow:function(e){
    wx.setClipboardData({
        data: e.currentTarget.dataset.text,
        success: function (res) {
          wx.getClipboardData({
            success: function (res) {
              wx.showToast({
                title: '复制成功',
                icon: 'none',
                duration: 2000
             })
            }
          })
        }
      })
  },

  //选择微信头像
  onChooseAvatar(e) {
    var that = this
    console.log(e.detail.avatarUrl)
    wx.uploadFile({
        url: 'https://www.wanfankeji19.xyz/copynew/public/api/syssetting/uploadimg',
        header: {// 设置请求的 header  
          'content-type': 'multipart/form-data'
        },
        filePath: e.detail.avatarUrl,
        name: 'img',
        success(res) {
            wx.hideLoading()
            var data = JSON.parse(res.data)
            console.log(data.code);
            console.log(data.data);
          if (data.code == 1) {
              var logoimgnow = data.data 
            wx.request({
                url: 'https://www.wanfankeji19.xyz/copynew/public/api/syssetting/uploadimgavatarurl',
                method: 'POST',
                header: {// 设置请求的 header  
                  'content-type': 'application/x-www-form-urlencoded'
                },
                data: {
                  openid: getApp().globalData.openid,
                  avatarurl:logoimgnow
                },
                success: function (res) {
                  wx.hideLoading()
                  if(res.data==1){
                      wx.showToast({
                          title: '更新成功',
                          icon: 'none',
                          duration: 2000
                      })
                      that.getuserinfo()
                  }
                },
                fail: function (res) {
                  wx.showToast({
                    title: '请求失败',
                  })
                },
              })
          } else {
            wx.showToast({
              title: res.data.data,
            })
            return
          }
        }
      })
  },

  //输入微信昵称方法
  setnickname: function (e) {
    this.setData({
    nickname: e.detail.value
    })
  },
  //输入名称方法
  setname: function (e) {
    this.setData({
    name: e.detail.value
    })
  },
  //输入手机号方法
  settel: function (e) {
    this.setData({
    tel: e.detail.value
    })
  },


  //更新logo
  changeimg: function (e) {
        var that = this;
        wx.chooseImage({
        count: 1,
        sizeType: ['original'], // 可以指定是原图还是压缩图，默认二者都有
        sourceType: ['album', 'camera'], // 可以指定来源是相册还是相机，默认二者都有
        success: function (res) {
            // 返回选定照片的本地文件路径列表，tempFilePath可以作为img标签的src属性显示图片
            console.log(res.tempFilePaths[0]);
            wx.showLoading({
                title: '加载中',
                mask: true
              })
              wx.uploadFile({
                url: 'https://www.wanfankeji19.xyz/copynew/public/api/syssetting/uploadimg',
                header: {// 设置请求的 header  
                  'content-type': 'multipart/form-data'
                },
                filePath: res.tempFilePaths[0],
                name: 'img',
                success(res) {
                    wx.hideLoading()
                    var data = JSON.parse(res.data)
                    console.log(data.code);
                    console.log(data.data);
                  if (data.code == 1) {
                      var logoimgnow = data.data 
                    //   wx.cropImage({
                    //     src: logoimgnow, // 图片路径
                    //     cropScale: '1:1', // 裁剪比例
                    //   })
                    wx.request({
                        url: 'https://www.wanfankeji19.xyz/copynew/public/api/syssetting/uploadimgavatarurl',
                        method: 'POST',
                        header: {// 设置请求的 header  
                          'content-type': 'application/x-www-form-urlencoded'
                        },
                        data: {
                          openid: getApp().globalData.openid,
                          avatarurl:logoimgnow
                        },
                        success: function (res) {
                          wx.hideLoading()
                          if(res.data==1){
                              wx.showToast({
                                  title: '更新成功',
                                  icon: 'none',
                                  duration: 2000
                              })
                              that.getuserinfo()
                          }
                        },
                        fail: function (res) {
                          wx.showToast({
                            title: '请求失败',
                          })
                        },
                      })
                  } else {
                    wx.showToast({
                      title: res.data.data,
                    })
                    return
                  }
                }
              })
        }
        })
  },

  afterRead(event) {
    const { file } = event.detail;
    // 当设置 mutiple 为 true 时, file 为数组格式，否则为对象格式
    wx.uploadFile({
      url: 'https://www.wanfankeji19.xyz/copynew/public/api/syssetting/uploadimg',
      filePath: file.url,
      name: 'file',
      formData: { user: 'test' },
      success(res) {
        // 上传完成需要更新 fileList
        const { fileList = [] } = this.data;
        fileList.push({ ...file, url: res.data });
        this.setData({ fileList });
      },
    });
  },

  //输入名字
  onChange_name(event) {
    console.log();
    this.setData({
        name:event.detail
      })
  },
  //输入微信名称
  onChange_busname(event) {
    console.log();
    this.setData({
        nickname:event.detail
      })
  },
  //输入手机号
  onChange_tel(event) {
    console.log();
    this.setData({
        tel:event.detail
      })
  },

  //获取手机号方法
  getphone: function (e) {
    if (e.detail.errMsg == 'getPhoneNumber:fail user deny') {
      wx.showToast({
        title: '请点击允许,获得手机号',
        icon: 'none'
      })
      return
    }
    if (e.detail.errMsg == 'getPhoneNumber:ok') {
      var that = this
      wx.showLoading({
        title: '加载中~',
        mask: true
      })
      wx.login({
        success: function (res) {
          if (res.code) {
            wx.request({
              url: 'https://www.wanfankeji19.xyz/copynew/public/api/syssetting/getphoneai',
              method: 'POST',
              header: {// 设置请求的 header  
                'content-type': 'application/x-www-form-urlencoded'
              },
              data: {
                appid: 1,
                openid: getApp().globalData.openid,
                code: res.code,
                encryptedData: e.detail.encryptedData,
                iv: e.detail.iv,
              },
              success: function (res) {
                wx.hideLoading()
                if (res.data == 0) {
                  wx.showToast({
                    title: '获取失败,请重试',
                    icon: 'none'
                  })
                } else {
                  that.setData({
                    tel: res.data
                  })
                }
              },
              fail: function (res) {
                wx.showToast({
                  title: '网络错误',
                  icon: 'none',
                  duration: 2000
                })
              }
            })
          } else {
            wx.showToast({
              title: '获取失败，请重试',
              icon: 'none',
              duration: 2000
            })
          }
        }
      });
    }
  },

  //更新信息方法
  submit:function(){
    if (this.data.nickname == "" || this.data.nickname==null){
      wx.showToast({
        title: '请输入微信昵称姓名',
        icon:'none'
      })
      return
    }
    var that = this
    wx.showLoading({
        title: '加载中...',
      })
    wx.request({
      url: 'https://www.wanfankeji19.xyz/copynew/public/api/syssetting/updateuserinfodetail',
      method: 'POST',
      header: {// 设置请求的 header  
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        appid: 1,
        openid: getApp().globalData.openid,
        name:that.data.name,
        nickname:that.data.nickname,
        tel:that.data.tel
      },
      success: function (res) {
        wx.hideLoading()
        if(res.data==1){
            wx.showToast({
                title: '更新成功',
                icon: 'none',
                duration: 2000
            })
        }
      },
      fail: function (res) {
        wx.showToast({
          title: '请求失败',
        })
      },
    })
  },


  //复制微信号方法
  copyweixin: function () {
    util.copyweixin()
  },

  //获取订单数量方法
  getuserinfo: function () {
    var that = this
    wx.showLoading({
        title: '加载中',
        mask: true
      })
    wx.request({
      url: 'https://www.wanfankeji19.xyz/copynew/public/api/syssetting/getuserinfodetail',
      method: 'POST',
      header: {// 设置请求的 header  
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        appid: 1,
        openid: getApp().globalData.openid
      },
      success: function (res) {
        wx.hideLoading()
        that.setData({
          name: res.data.name,
          tel: res.data.tel,
          nickname: res.data.nickname,
          avatarurl: res.data.avatarurl,
          openid:res.data.openid
        })
      },
      fail: function (res) {
        wx.showToast({
          title: '请求失败',
        })
      },
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.getuserinfo()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
})