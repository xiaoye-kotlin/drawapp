// pages/about/about.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    wechat:'zt19989022',
    phone:'18669118324'
  },


  //复制微信
  copynow:function(e){
    wx.setClipboardData({
        data: e.currentTarget.dataset.text,
        success: function (res) {
          wx.getClipboardData({
            success: function (res) {
              wx.showToast({
                title: '复制成功',
                icon: 'none',
                duration: 2000
             })
            }
          })
        }
      })
  },
  
  //点击查看图片
  previewImage: function (e) {
      var that = this
    wx.previewImage({
      current: 1, // 当前显示图片的http链接
      urls: [that.data.quncode] // 需要预览的图片http链接列表
    })
  },

  //打电话
  callbus:function(e){
      var that = this
    wx.makePhoneCall({
      phoneNumber: that.data.phone,
      success: function () {
      }
    })
  },


  /**
   * 生命周期函数--监听页面加载
   */
  onLoad(options) {
     
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady() {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow() {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide() {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload() {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh() {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom() {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage() {

  }
})