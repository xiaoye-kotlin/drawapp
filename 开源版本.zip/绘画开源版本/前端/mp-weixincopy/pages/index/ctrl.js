"use strict";
const common_vendor = require("../../common/vendor.js");
const common_config = require("../../common/config.js");
const _sfc_main = {
  data() {
    return {
      // 广告信息设置
      adjinfo: "",
      // 管理员微信
      manavx: "",
      addkeynum: "",
      openid: "",
      sup: 0,
      // 大盘数据
      showlist: [],
      // 折叠面板当前打开
      choicecoll: null,
      // key状态值
      keystatu: 1,
      // 总人数
      allusernum: 2,
      // 今日增加
      dayadduser: 3,
      // 问答总数
      allanswnum: 4,
      // 每日免费次数
      daynum: 0,
      // 分享赠送次数
      sharenum: 0,
      // 分享赠送次数
      sharemaxnum: 0,
      // 视频赠送次数
      videonum: 0,
      // 视频赠送次数
      videomaxnum: 0,
      // 广告开关
      isadj: false,
      // 会员账号
      addnumid: "",
      // 充值次数
      addnumcount: 0,
      // apikey
      keylist: []
    };
  },
  onLoad() {
    this.init();
    console.log("load");
    this.getuserinfo();
  },
  methods: {
    // 打开key弹窗
    open() {
      console.log("pop");
      this.$refs.addkeypop.open("center");
    },
    // 关闭key弹窗
    close() {
      this.$refs.addkeypop.close("center");
    },
    // 广告开关
    adjset(e) {
      console.log(e.detail.value);
      this.isadj = e.detail.value;
    },
    // 页面初始化
    init() {
      this.sup = 1;
    },
    // 获取用户信息
    wxcode() {
      let that = this;
      common_vendor.index.login({
        provider: "weixin",
        //使用微信登录
        success: function(loginRes) {
          console.log(loginRes.code);
          let data = JSON.stringify({
            code: loginRes.code
          });
          common_vendor.index.request({
            url: common_config.config.apiurl + "/login",
            data,
            method: "POST",
            success: (res) => {
              console.log(res);
              that.openid = res.data.resmsg.openid;
              if (res.data.resmsg.openid == res.data.mana) {
                that.sup = 1;
              } else {
                common_vendor.index.navigateTo({
                  url: "/pages/index/index"
                });
              }
            },
            fail: (err) => {
              this.toast(err);
            }
          });
        }
      });
    },
    // 提示框封装
    toast(msg) {
      common_vendor.index.showToast({
        title: msg,
        duration: 2e3,
        icon: "none"
      });
    },
    // 折叠变化
    collchange(e) {
      console.log(e);
      switch (e) {
        case "0":
          console.log("参数配置");
          this.getsetinfo();
          break;
        case "1":
          console.log("会员充值");
          break;
        case "2":
          console.log("key配置");
          this.getapilist();
          break;
        case "3":
          console.log("广告配置");
          this.getadjinfo();
          break;
      }
    },
    // 获取广告信息
    getadjinfo() {
      common_vendor.index.request({
        url: common_config.config.apiurl,
        method: "GET",
        success: (res) => {
          console.log(res);
          this.adjinfo = res.data.adj;
        }
      });
    },
    // 获取程序运营数据
    getuserinfo() {
      common_vendor.index.request({
        url: common_config.config.apiurl + "/userinfo",
        method: "GET",
        success: (res) => {
          console.log(res);
          this.allusernum = res.data.allusernum;
          this.dayadduser = res.data.dayadduser;
          this.allanswnum = res.data.allanswnum;
        },
        fail: (err) => {
          this.toast(err);
        }
      });
    },
    // 获取参数配置信息
    getsetinfo() {
      console.log("获取配置信息");
      common_vendor.index.request({
        url: common_config.config.apiurl + "/getsetinfo",
        method: "GET",
        success: (res) => {
          console.log(res);
          this.daynum = res.data.daynum;
          this.sharenum = res.data.sharenum;
          this.videonum = res.data.videonum;
          this.sharemaxnum = res.data.sharemaxnum;
          this.videomaxnum = res.data.videomaxnum;
          this.isadj = res.data.isadj;
          this.manavx = res.data.manavx;
        },
        fail: (err) => {
          this.toast(err);
        }
      });
    },
    // 参数确定修改
    setenter() {
      console.log("获取配置信息");
      let data = JSON.stringify({
        daynum: this.daynum,
        sharenum: this.sharenum,
        videonum: this.videonum,
        sharemaxnum: this.sharemaxnum,
        videomaxnum: this.videomaxnum,
        isadj: this.isadj,
        manavx: this.manavx
      });
      common_vendor.index.request({
        url: common_config.config.apiurl + "/setinfo",
        data,
        method: "POST",
        success: (res) => {
          console.log(res);
          this.daynum = res.data.daynum;
          this.sharenum = res.data.sharenum;
          this.videonum = res.data.videonum;
          this.sharemaxnum = res.data.sharemaxnum;
          this.videomaxnum = res.data.videomaxnum;
          this.isadj = res.data.isadj;
          this.manavx = res.data.manavx;
          if (res.data.code == 200) {
            this.toast("修改成功");
            this.choicecoll = "";
          }
        },
        fail: (err) => {
          this.toast(err);
        }
      });
    },
    // 确认充值
    enteraddnum() {
      let that = this;
      common_vendor.index.login({
        provider: "weixin",
        //使用微信登录
        success: function(loginRes) {
          console.log(loginRes.code);
          let data = JSON.stringify({
            code: loginRes.code,
            userid: that.addnumid,
            num: that.addnumcount
          });
          common_vendor.index.request({
            url: common_config.config.apiurl + "/manaaddnum",
            data,
            method: "POST",
            success: (res) => {
              if (res.data.code == 200) {
                console.log(res.data);
                that.toast("充值成功，次数：" + res.data.num);
              }
            }
          });
        }
      });
    },
    // 确认设置广告
    editadjinfo() {
      let that = this;
      common_vendor.index.login({
        provider: "weixin",
        //使用微信登录
        success: function(loginRes) {
          console.log(loginRes.code);
          let data = JSON.stringify({
            code: loginRes.code,
            adjinfo: that.adjinfo
          });
          common_vendor.index.request({
            url: common_config.config.apiurl + "/setadj",
            data,
            method: "POST",
            success: (res) => {
              if (res.data.code == 200) {
                console.log(res.data);
                that.toast("广告设置成功");
              }
            }
          });
        }
      });
    },
    // 获取apikey
    getapilist() {
      common_vendor.index.request({
        url: common_config.config.apiurl + "/getapilist",
        method: "GET",
        success: (res) => {
          console.log(res);
          this.keylist = res.data.apilist;
        },
        fail: (err) => {
          this.toast(err);
        }
      });
    },
    addkey() {
      this.open();
    },
    // apikey新增保存
    apikeyadd() {
      let data = JSON.stringify({
        apikey: this.addkeynum
      });
      common_vendor.index.request({
        url: common_config.config.apiurl + "/editapi",
        data,
        method: "POST",
        success: (res) => {
          console.log(res);
          this.keylist = res.data.apilist;
          this.toast("新增成功");
        },
        fail: (err) => {
          this.toast(err);
        }
      });
      this.close();
    },
    // 删除key
    delkey(key) {
      let data = JSON.stringify({
        apikey: key
      });
      common_vendor.index.request({
        url: common_config.config.apiurl + "/delkey",
        data,
        method: "POST",
        success: (res) => {
          console.log(res);
          this.keylist = res.data.apilist;
          this.toast("删除成功");
        },
        fail: (err) => {
          this.toast(err);
        }
      });
    },
    // 检测key
    checkkey(key) {
      let data = JSON.stringify({
        apikey: key
      });
      common_vendor.index.request({
        url: common_config.config.apiurl + "/checkapi",
        data,
        method: "POST",
        success: (res) => {
          console.log(res);
          this.keylist = res.data.apilist;
          this.toast("检测完成");
        },
        fail: (err) => {
          this.toast(err);
        }
      });
    }
  }
};
if (!Array) {
  const _easycom_uni_easyinput2 = common_vendor.resolveComponent("uni-easyinput");
  const _easycom_uni_collapse_item2 = common_vendor.resolveComponent("uni-collapse-item");
  const _easycom_uni_tag2 = common_vendor.resolveComponent("uni-tag");
  const _easycom_uni_collapse2 = common_vendor.resolveComponent("uni-collapse");
  const _easycom_uni_popup2 = common_vendor.resolveComponent("uni-popup");
  (_easycom_uni_easyinput2 + _easycom_uni_collapse_item2 + _easycom_uni_tag2 + _easycom_uni_collapse2 + _easycom_uni_popup2)();
}
const _easycom_uni_easyinput = () => "../../uni_modules/uni-easyinput/components/uni-easyinput/uni-easyinput.js";
const _easycom_uni_collapse_item = () => "../../uni_modules/uni-collapse/components/uni-collapse-item/uni-collapse-item.js";
const _easycom_uni_tag = () => "../../uni_modules/uni-tag/components/uni-tag/uni-tag.js";
const _easycom_uni_collapse = () => "../../uni_modules/uni-collapse/components/uni-collapse/uni-collapse.js";
const _easycom_uni_popup = () => "../../uni_modules/uni-popup/components/uni-popup/uni-popup.js";
if (!Math) {
  (_easycom_uni_easyinput + _easycom_uni_collapse_item + _easycom_uni_tag + _easycom_uni_collapse + _easycom_uni_popup)();
}
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return common_vendor.e({
    a: $data.sup
  }, $data.sup ? {
    b: common_vendor.t($data.allusernum),
    c: common_vendor.t($data.dayadduser),
    d: common_vendor.t($data.allanswnum),
    e: common_vendor.o(($event) => $data.daynum = $event),
    f: common_vendor.p({
      trim: "all",
      type: "number",
      modelValue: $data.daynum
    }),
    g: common_vendor.o(($event) => $data.sharenum = $event),
    h: common_vendor.p({
      trim: "all",
      type: "number",
      modelValue: $data.sharenum
    }),
    i: common_vendor.o(($event) => $data.sharemaxnum = $event),
    j: common_vendor.p({
      trim: "all",
      type: "number",
      modelValue: $data.sharemaxnum
    }),
    k: common_vendor.o(($event) => $data.videonum = $event),
    l: common_vendor.p({
      trim: "all",
      type: "number",
      modelValue: $data.videonum
    }),
    m: common_vendor.o(($event) => $data.videomaxnum = $event),
    n: common_vendor.p({
      trim: "all",
      type: "number",
      modelValue: $data.videomaxnum
    }),
    o: common_vendor.o(($event) => $data.manavx = $event),
    p: common_vendor.p({
      trim: "all",
      modelValue: $data.manavx
    }),
    q: $data.isadj,
    r: common_vendor.o((...args) => $options.adjset && $options.adjset(...args)),
    s: common_vendor.o((...args) => $options.setenter && $options.setenter(...args)),
    t: common_vendor.p({
      title: "参数配置:"
    }),
    v: common_vendor.o(($event) => $data.addnumid = $event),
    w: common_vendor.p({
      trim: "all",
      modelValue: $data.addnumid
    }),
    x: common_vendor.o(($event) => $data.addnumcount = $event),
    y: common_vendor.p({
      trim: "all",
      type: "number",
      modelValue: $data.addnumcount
    }),
    z: common_vendor.o((...args) => $options.enteraddnum && $options.enteraddnum(...args)),
    A: common_vendor.p({
      title: "会员充值"
    }),
    B: common_vendor.f($data.keylist, (item, k0, i0) => {
      return {
        a: "1aa5320e-12-" + i0 + ",1aa5320e-11",
        b: common_vendor.o(($event) => item.key = $event),
        c: common_vendor.p({
          trim: "all",
          disabled: true,
          modelValue: item.key
        }),
        d: "1aa5320e-13-" + i0 + ",1aa5320e-11",
        e: common_vendor.p({
          text: item.usernum,
          type: ""
        }),
        f: "1aa5320e-14-" + i0 + ",1aa5320e-11",
        g: common_vendor.p({
          text: item.keystatu == 1 ? "正常" : "异常",
          type: item.keystatu == 1 ? "success" : "error"
        }),
        h: common_vendor.o(($event) => $options.checkkey(item.key)),
        i: "1aa5320e-15-" + i0 + ",1aa5320e-11",
        j: common_vendor.o(($event) => $options.delkey(item.key)),
        k: "1aa5320e-16-" + i0 + ",1aa5320e-11"
      };
    }),
    C: common_vendor.p({
      text: "检测",
      type: "primary"
    }),
    D: common_vendor.p({
      text: "删除",
      type: "error"
    }),
    E: common_vendor.o((...args) => $options.addkey && $options.addkey(...args)),
    F: common_vendor.p({
      title: "key配置"
    }),
    G: common_vendor.o(($event) => $data.adjinfo = $event),
    H: common_vendor.p({
      trim: "all",
      modelValue: $data.adjinfo
    }),
    I: common_vendor.o((...args) => $options.editadjinfo && $options.editadjinfo(...args)),
    J: common_vendor.p({
      title: "广告配置"
    }),
    K: common_vendor.o($options.collchange),
    L: common_vendor.o(($event) => $data.choicecoll = $event),
    M: common_vendor.p({
      accordion: true,
      modelValue: $data.choicecoll
    }),
    N: $data.addkeynum,
    O: common_vendor.o(($event) => $data.addkeynum = $event.detail.value),
    P: common_vendor.o((...args) => $options.apikeyadd && $options.apikeyadd(...args)),
    Q: common_vendor.sr("addkeypop", "1aa5320e-19"),
    R: common_vendor.p({
      type: "center"
    })
  } : {});
}
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-1aa5320e"], ["__file", "C:/wp/AI/2023-3-14/绘画开源版/wxchat1/pages/index/ctrl.vue"]]);
wx.createPage(MiniProgramPage);
