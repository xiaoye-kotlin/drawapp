
"use strict";
const common_vendor = require("../../common/vendor.js");
const common_uniCopy = require("../../common/uni-copy.js");
const common_config = require("../../common/config.js");
const ourLoading = () => "../../components/our-loading/our-loading.js";
var videoAd = null;
const _sfc_main = {
  components: {
    ourLoading
  },
  data() {
    return {
      // 广告开关
      isadj: false,
      apiurl: "",
      // apiurl: 'http://127.0.0.1:5000',
      // 联系人微信
      contactperson: "LLyy0207-",
      loadset: true,
      // 充值时用户id
      userid: "",
      // 充值时次数
      manaaddnum: null,
      // 分享话术
      loading: true,
      show: "",
      // 侧边原生广告id
      adj1: "adunit-d920d0253bb72932",
      // 视频广告
      adjvideo: "adunit-5be95a0bcd09ba41",
      // 广告内容
      adj: "",
      // 是否管理员
      managerstatu: false,
      // 上下文模式
      modetype: 3,
      // openid
      openid: "",
      // 模式选择
      range: [
        {
          value: 2,
          text: "一问一答模式"
        },
        {
          value: 3,
          text: "上下文模式"
        },
        {
          value: 4,
          text: "AI绘图模式"
        }
      ],
      scrollInto: "",
      // 发送按钮文字
      sentext: "发送",
      msgLoad: false,
      // 聊天对话内容
      msgList: [{
        "msg": "你好,我是人工ai问答手,我会尽可能帮助解答你的问题~",
        "my": false
      }],
      // 发送的消息体
      msgContent: "",
      // 输入的问题
      msg: "",
      // 发送消息临时变量
      sendmsgcache: [],
      // 可使用次数
      num: 0,
      informs: "",
      conversationid: "",
    };
  },

 

  onLoad(options) {
    var that = this
    that.apiurl = common_config.config.apiurl;
    that.contactperson = common_config.config.contactperson;
    console.log(that.apiurl);
    that.sentext = "加载中";
    that.msgLoad = true
    that.setdate
    that.wxcode();
    that.getsetinfo();
    that.adLoad();
    console.log(getApp().globalData.avatarurl);
    // if(options.type == 2){
    //     var e = options.type*1
    //     that.change(e)

        
    // }
    // if(options.type == 3){
    //     var e = options.type*1
    //     that.change(e)
    //     that.setData({
    //         modetype: 3
    //     })
    // }
    if(options.type == 4){
        var e = options.type*1
        that.change(e)
    }
  },


  methods: {
    addnumcopy() {
      this.copy(this.openid);
      this.closeaddnumpop();
    },
    // 充值弹窗
    openaddnumpop() {
      this.$refs.addnumpop.open("center");
    },
    closeaddnumpop() {
      this.$refs.addnumpop.close("center");
    },
    // 获取参数配置信息
    getsetinfo() {
      common_vendor.index.request({
        url: common_config.config.apiurl + "/getsetinfo",
        method: "GET",
        success: (res) => {
          console.log(res);
          this.isadj = res.data.isadj;
          if (res.data.manavx != null) {
            this.contactperson = res.data.manavx;
          }
        },
        fail: (err) => {
          this.toast(err);
        }
      });
    },



    aaa:function(e){
        console.log(111);
    },

    // 获取头像
    onChooseAvatar(e) {
      console.log(e.detail);
      this.avatar = e.detail.avatarUrl;
      common_vendor.index.setStorage({
        key: "avat",
        data: apikey,
        success: function(res) {
          console.log("success", res);
        }
      });
    },
    // 跳转首页
    toindex() {
      common_vendor.index.navigateTo({
        url: "/pages/index/index"
      });
    },
    // 跳转旧版
    togpt() {
      common_vendor.index.navigateTo({
        url: "/pages/gpt/gpt"
      });
    },
    onShareAppMessage(res) {
      if (res.from === "button") {
        console.log(res.target);
      }
      return {
        title: "AI智能问答",
        path: "/pages/index/index"
      };
    },
    onShareTimeline(res) {
      if (res.from === "button") {
        console.log(res.target);
      }
      return {
        title: "AI智能问答",
        path: "/pages/index/index"
      };
    },
    // 网络失败封装
    neterr(err) {
      this.msgList[this.msgList.length - 1].msg = "服务器有点忙，重新问问试试，一直不好用的话请联系微信：" + this.contactperson + "  故障原因:" + String(err);
      let that = this;
      setTimeout(function() {
        that.msgLoad = false;
        that.sentext = "发送";
      }, 3e3);
    },
    // 提示框封装
    toast(msg) {
      common_vendor.index.showToast({
        title: msg,
        duration: 2e3,
        icon: "none"
      });
    },
    // 选择角色
    chioceuse() {
      this.toast("暂未开放");
      common_vendor.index.getUserProfile({
        desc: "獲取您的昵稱、頭像、地區及性別",
        success: (infoRes) => {
          console.log(infoRes);
        },
        fail: (err) => {
          console.log("userInfo-err", JSON.stringify(err));
        }
      });
    },
    // 管理员充值
    manaadd() {
      common_vendor.index.navigateTo({
        url: "/pages/index/ctrl"
      });
    },
    // 管理员参数配置
    manaset() {
      common_vendor.index.navigateTo({
        url: "/pages/index/ctrl"
      });
      this.closeDrawer();
    },
    // 增加次数
    addnum(ty) {
      let data = JSON.stringify({
        openid: this.openid,
        type: ty
      });
      common_vendor.index.request({
        url: this.apiurl + "/addnum",
        data,
        method: "POST",
        success: (res) => {
          console.log("增加次数", res);
          if (res.data.code == 200) {
            this.num = res.data.num;
            this.toast("任务完成，次数增加");
            this.msgList[this.msgList.length - 1].msg = "次数增加，欢迎回来";
            this.close();
          }
          if (res.data.code == 201) {
            this.msgList[this.msgList.length - 1].msg = res.data.msg;
            this.toast(res.data.msg);
            this.close();
          }
        },
        fail: (err) => {
          this.neterr(err);
        }
      });
    },
    // 视频激励播放
    adLoad: function() {
      if (common_vendor.wx$1.createRewardedVideoAd) {
        videoAd = common_vendor.wx$1.createRewardedVideoAd({
          adUnitId: this.adjvideo
          //你的广告key
        });
        videoAd.onError((err) => {
        });
        videoAd.onClose((status) => {
          if (status && status.isEnded || status === void 0) {
            videoAd.offClose();
            console.log("播放完成");
            this.addnum("v");
          } else {
            console.log("退出播放");
          }
        });
      }
    },
    // 广告加载
    showAd() {
      if (videoAd) {
        videoAd.show().catch((err) => {
          videoAd.load().then(() => videoAd.show());
        });
      }
    },
    // 分享
    shar() {
      this.addnum("s");
    },
    // 打开弹窗
    open() {
      console.log("pop");
      this.$refs.popup.open("bottom");
    },
    // 关闭弹窗
    close() {
      this.$refs.popup.close("bottom");
    },
    // 界面滚动
    setPageScrollTo() {
      let len = this.msgList.length;
      this.scrollInto = "id" + (len - 1);
    },
    // 发送消息
    sendmsg() {
      console.log(this.msg.length);
      if (this.sentext == "故障" || this.sentext == "重试") {
        this.checkserve();
        return 0;
      }
      if (this.num < 1 && this.sentext != "故障") {
        console.log("需充值");
        this.msgList.push({
          "msg": "可用次数不足",
          "my": false
        });
        this.open();
        return 0;
      }
      if (this.msg == "") {
        console.log("msg为空");
        this.toast("请先输入问题");
        return 0;
      }
      if (this.msgLoad == true) {
        console.log("load中");
        return 0;
      }
      this.sentext = "请求中";
      this.msgList.push({
        "msg": this.msg,
        "my": true
      });
      this.msgList.push({
        "msg": "答案生成中......",
        "my": false
      });
      let data = "";
      switch (this.modetype) {
        case 4:
          console.log(this.modetype, "4");
          data = JSON.stringify({
            msg: this.msg,
            maxtoken: 3664,
            msgcache: this.msgContent,
            conversationid: this.conversationid,
            openid: this.openid
          });
          break;
        case 3:
          console.log(this.modetype, "3");
          this.sendmsgcache.push("YOU:" + this.msg + "\n");
          this.msgContent = "";
          this.sendmsgcache.forEach((info) => {
            console.log("info", info);
            this.msgContent += info;
          });
          data = JSON.stringify({
            msg: this.msgContent,
            maxtoken: 3700 - this.msgContent.length * 2,
            msgcache: this.msgContent,
            conversationid: this.conversationid,
            openid: this.openid
          });
          break;
        case 2:
          console.log(this.modetype, "2");
          data = JSON.stringify({
            msg: this.msg,
            maxtoken: 3700 - this.msg.length * 2,
            msgcache: this.msgContent,
            conversationid: this.conversationid,
            openid: this.openid
          });
          break;
      }
      console.log(data);
      this.msgLoad = true;
      this.msg = "";
      this.setPageScrollTo();
      let count = 0;
      let timer = setInterval(() => {
        count++;
        if (count == 5) {
          this.msgList[this.msgList.length - 1].msg = "回答内容越长，反应时间越慢，请耐心等待,马上就好....";
        }
        if (count == 10) {
          this.msgList[this.msgList.length - 1].msg = "回答一定是个超级长的内容,马上就好....";
        }
        if (count == 20) {
          this.msgList[this.msgList.length - 1].msg = "千万不要着急哦,给小帆一点时间....";
        }
        if (count == 30) {
          this.msgList[this.msgList.length - 1].msg = "内容生成中,即将呈现....";
        }
        // if (count == 40) {
        //   this.msgList[this.msgList.length - 1].msg = "可能超出小帆的能力范围,正在努力学习中....";
        // }
      }, 1e3);
      console.log(this.modetype);
      if (this.modetype === 4) {
        common_vendor.index.request({
          url: this.apiurl + "/image",
          data,
          method: "POST",
          timeout: 18e4,
          success: (res) => {
            if (res.data.code == 200) {
              console.log(res);
              clearInterval(timer);
              timer = null;
              this.msgList[this.msgList.length - 1].msg = res.data.resmsg.data[0].url;
              this.setPageScrollTo();
              console.log("su", this.msgList);
              this.sendmsgcache.push(res.data.resmsg.data[0].url + "\n");
              this.num = res.data.num;
              this.msgLoad = false;
              this.sentext = "发送";
            }
          }
        });
      } else {
        common_vendor.index.request({
          url: this.apiurl + "/message",
          data,
          method: "POST",
          timeout: 18e4,
          success: (res) => {
            if (res.data.code == 200) {
              let text = res.data.resmsg.choices[0].text.replace("openai:", "").replace(
                "openai：",
                ""
              ).replace(/^\n|\n$/g, "").replace(/^\s+/, "");
              console.log(text);
              let msglen = res.data.resmsg.usage.total_tokens;
              let msgcomplen = res.data.resmsg.usage.completion_tokens;
              if (msglen + msgcomplen > 1500) {
                for (let msg in this.sendmsgcache) {
                  this.sendmsgcache.shift();
                  if (this.msgContent.length * 1.6 + msglen < 800) {
                    console.log("ok");
                    break;
                  }
                }
              }
              clearInterval(timer);
              timer = null;
              if (text != "") {
                this.msgList[this.msgList.length - 1].msg = text;
              }
              if (text == "") {
                this.msgList[this.msgList.length - 1].msg = "你好像没有问问题，加上你想问的问题或者换个问法再试试";
              }
              this.setPageScrollTo();
              console.log("su", this.msgList);
              this.sendmsgcache.push(text + "\n");
              this.num = res.data.num;
              this.msgLoad = false;
              this.sentext = "发送";
            } else {
              clearInterval(timer);
              timer = null;
              this.neterr(res.data.errinfo);
            }
          },
          fail: (res) => {
            this.neterr(res);
          }
        });
      }
    },
    // 次数点击
    topupnum() {
      console.log("次数点击");
    },
    // 复制内容
    copy(info) {
      common_uniCopy.uniCopy({
        content: info,
        success: (res) => {
          common_vendor.index.showToast({
            title: res,
            icon: "none"
          });
        },
        error: (e) => {
          common_vendor.index.showToast({
            title: e,
            icon: "none",
            duration: 3e3
          });
        }
      });
    },
    // 检测服务连接
    checkserve() {
      this.msgLoad = true;
      this.sentext = "连接中";
      common_vendor.index.request({
        url: this.apiurl,
        method: "GET",
        success: (res) => {
          console.log("联通测试", res);
          if (res.data.code == 200) {
            console.log(res);
            this.sentext = "发送";
            this.msgLoad = false;
            this.adj = res.data.adj;
          } else {
            this.msgList.push({
              "msg": "服务器故障，请联系微信：" + this.contactperson + "  故障原因:" + res.data.resmsg,
              "my": false
            });
            this.sentext = "故障";
            setTimeout(function() {
              this.msgLoad = true;
            }, 1e4);
          }
        },
        fail: (err) => {
          this.neterr(err);
        }
      });
    },
    // 获取用户信息
    wxcode() {
      let that = this;
      common_vendor.index.login({
        provider: "weixin",
        //使用微信登录
        success: function(loginRes) {
          console.log(loginRes.code);
          let data = JSON.stringify({
            code: loginRes.code
          });
          common_vendor.index.request({
            url: that.apiurl + "/login",
            data,
            method: "POST",
            success: (res) => {
              if (res.data.code == 200) {
                console.log(res);
                that.sentext = "发送";
                that.msgLoad = false;
                console.log(res);
                that.openid = res.data.resmsg.openid;
                that.num = res.data.num;
                if (res.data.resmsg.openid == res.data.mana) {
                  that.managerstatu = true;
                }
                that.loadset = false;
                that.checkserve();
              } else {
                that.msgList.push({
                  "msg": "服务器故障，请联系微信：" + that.contactperson + "  故障原因:" + res.data.resmsg,
                  "my": false
                });
                that.sentext = "故障";
                setTimeout(function() {
                  that.msgLoad = true;
                }, 1e4);
              }
            },
            fail: (err) => {
              this.neterr(err);
            }
          });
        }
      });
    },
    // 会话ID
    concentid() {
      this.conversationid = this.openid + Date.now();
      console.log(this.conversationid);
    },
    // 模式变更
    change(e) {
      this.concentid();
      console.log("e:", e);
      this.sendmsgcache = [];
      this.toast("模式变更后，对话逻辑会从新开始");
      switch (e) {
        case 4:
          this.informs = "当前选择模式为绘画模式，请进行描述";
          break;
        case 3:
          this.informs = "当前选择模式为上下文模式，从现在开始的问答会影响AI回复的逻辑，需要清空逻辑重新开始的话，直接重新选择模式就可以";
          break;
        case 2:
          this.informs = "当前选择模式为一问一答模式，每次的问答无上下文关联，可以一次性将问题描述详细，AI回答的内容越多，需要等待的时间越长";
          break;
      }
      this.msgList.push({
        "msg": this.informs,
        "my": false
      });
    },
    // 侧边抽屉
    showDrawer() {
      this.$refs.showRight.open();
    },
    closeDrawer() {
      this.$refs.showRight.close();
    }
  }
};
if (!Array) {
  const _component_ourLoading = common_vendor.resolveComponent("ourLoading");
  const _easycom_uni_data_select2 = common_vendor.resolveComponent("uni-data-select");
  const _easycom_uni_notice_bar2 = common_vendor.resolveComponent("uni-notice-bar");
  const _easycom_uni_icons2 = common_vendor.resolveComponent("uni-icons");
  const _easycom_uni_drawer2 = common_vendor.resolveComponent("uni-drawer");
  const _easycom_uni_popup2 = common_vendor.resolveComponent("uni-popup");
  (_component_ourLoading + _easycom_uni_data_select2 + _easycom_uni_notice_bar2 + _easycom_uni_icons2 + _easycom_uni_drawer2 + _easycom_uni_popup2)();
}
const _easycom_uni_data_select = () => "../../uni_modules/uni-data-select/components/uni-data-select/uni-data-select.js";
const _easycom_uni_notice_bar = () => "../../uni_modules/uni-notice-bar/components/uni-notice-bar/uni-notice-bar.js";
const _easycom_uni_icons = () => "../../uni_modules/uni-icons/components/uni-icons/uni-icons.js";
const _easycom_uni_drawer = () => "../../uni_modules/uni-drawer/components/uni-drawer/uni-drawer.js";
const _easycom_uni_popup = () => "../../uni_modules/uni-popup/components/uni-popup/uni-popup.js";
if (!Math) {
  (_easycom_uni_data_select + _easycom_uni_notice_bar + _easycom_uni_icons + _easycom_uni_drawer + _easycom_uni_popup)();
}
function _sfc_render(_ctx, _cache, $props, $setup, $data, $options) {
  return common_vendor.e({
    a: $data.loadset,
    b: common_vendor.p({
      isFullScreen: true,
      active: true,
      text: "你想知道的,它都会告诉你...."
    }),
    c: common_vendor.o($options.change),
    d: common_vendor.o(($event) => $data.modetype = $event),
    e: common_vendor.p({
      localdata: $data.range,
      modelValue: $data.modetype
    }),
    f: $data.num > 0
  }, $data.num > 0 ? {
    g: common_vendor.t($data.num)
  } : {}, {
    h: $data.num <= 0
  }, $data.num <= 0 ? {} : {}, {
    i: common_vendor.o((...args) => $options.openaddnumpop && $options.openaddnumpop(...args)),
    j: common_vendor.p({
      scrollable: true,
      single: true,
      text: $data.adj,
      speed: "50"
    }),
    k: common_vendor.f($data.msgList, (x, i, i0) => {
      return common_vendor.e({
        a: x.my
      }, x.my ? {
        b: common_vendor.t(x.msg),
        c: "id" + i,
        d: common_vendor.o(($event) => $options.copy(x.msg), i)
      } : {}, {
        e: !x.my
      }, !x.my ? common_vendor.e({
        f: x.msg.indexOf("https://oaidalleapiprodscus") > -1
      }, x.msg.indexOf("https://oaidalleapiprodscus") > -1 ? {
        g: x.msg
      } : {
        h: common_vendor.t(x.msg)
      }, {
        i: "id" + i,
        j: common_vendor.o(($event) => $options.copy(x.msg), i)
      }) : {}, {
        k: i
      });
    }),
    l: $data.scrollInto,
    m: common_vendor.o($options.showDrawer),
    n: common_vendor.p({
      type: "settings-filled",
      size: "30"
    }),
    o: common_vendor.o((...args) => $options.sendmsg && $options.sendmsg(...args)),
    p: $data.msg,
    q: common_vendor.o(($event) => $data.msg = $event.detail.value),
    r: common_vendor.t($data.sentext),
    s: common_vendor.o((...args) => $options.sendmsg && $options.sendmsg(...args)),
    t: $data.msgLoad,
    v: common_vendor.t($data.openid),
    w: common_vendor.o(($event) => $options.copy($data.openid)),
    x: $data.managerstatu
  }, $data.managerstatu ? {
    y: common_vendor.o((...args) => $options.manaset && $options.manaset(...args))
  } : {}, {
    z: common_vendor.t($data.adj),
    A: $data.adj1,
    B: common_vendor.sr("showRight", "1cf27b2a-4"),
    C: common_vendor.p({
      mode: "left"
    }),
    D: $data.isadj
  }, $data.isadj ? {
    E: common_vendor.o((...args) => $options.showAd && $options.showAd(...args))
  } : {}, {
    F: common_vendor.o((...args) => $options.shar && $options.shar(...args)),
    G: common_vendor.t($data.contactperson),
    H: common_vendor.o((...args) => $options.openaddnumpop && $options.openaddnumpop(...args)),
    I: common_vendor.sr("popup", "1cf27b2a-5"),
    J: common_vendor.p({
      type: "bottom"
    }),
    K: common_vendor.o(($event) => $options.addnumcopy($data.openid)),
    L: common_vendor.t($data.contactperson),
    M: common_vendor.sr("addnumpop", "1cf27b2a-6"),
    N: common_vendor.p({
      type: "center"
    })
  });
}
const MiniProgramPage = /* @__PURE__ */ common_vendor._export_sfc(_sfc_main, [["render", _sfc_render], ["__scopeId", "data-v-1cf27b2a"], ["__file", "C:/wp/AI/2023-3-14/绘画开源版/wxchat1/pages/index/index.vue"]]);
_sfc_main.__runtimeHooks = 6;
wx.createPage(MiniProgramPage);
