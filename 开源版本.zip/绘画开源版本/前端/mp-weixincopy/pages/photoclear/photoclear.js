// pages/myinfo/myinfo.js
var util = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    total:0,
    page:1,
    text:'',
    hits:''
  },

  
  //输入要求
  setmask_file: function (e) {
    this.setData({
        mask_file: e.detail.value,
    })
  },
  //输入要求
  setimage_file: function (e) {
    this.setData({
        image_file: e.detail.value,
    })
  },

  //保存图片到相册
  baocun:function(e){
      console.log(e.currentTarget.dataset.img);
      wx.downloadFile({
        url: e.currentTarget.dataset.img,
        success: function (res) {
          wx.saveImageToPhotosAlbum({
            filePath: res.tempFilePath,
            success: function () {
              wx.showToast({
                title: '保存成功'
              })
            },
            fail: function () {
              wx.showToast({
                title: '保存失败',
                icon: 'none'
              })
            }
          })
        }
      })
    },

  //查询
  submit:function(){
    var that = this
    if (that.data.image_file == "" ){
        wx.showToast({
          title: '请上传原始图像',
          icon:'none'
        })
        return
      }
      if (that.data.mask_file == "" ){
        wx.showToast({
          title: '请上传需要蒙版图像',
          icon:'none'
        })
        return
      }
    wx.showLoading({
        title: '生成中...',
      })
    wx.request({
      url: 'https://www.wanfankeji19.xyz/copynew/public/api/wanfanai/clearphoto',
      method: 'POST',
      header: {// 设置请求的 header  
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        image_file:that.data.image_file,
        mask_file:that.data.mask_file,
      },
      success: function (res) {
        wx.hideLoading()
        if(res.data.total==0){
            wx.showToast({
                title: '暂无匹配图片',
                icon: 'none',
                duration: 2000
            })
        }else{
            that.setData({
                hits:res.data.hits,
                total:res.data.total
            })
            var imgarr = []
            for (var i = 0; i < res.data.hits.length; i++) {
                imgarr.push(res.data.hits[i]['largeImageURL'])
              }
              that.setData({
                imgarr:imgarr
            })
        }
      },
      fail: function (res) {
        wx.showToast({
          title: '请求失败',
        })
      },
    })
  },


  //点击查看图片
  previewImage: function (e) {
    var that = this
    var imgArr = that.data.imgarr;
    var index = e.currentTarget.dataset.index;
    console.log(imgArr);
    console.log(index);
    wx.previewImage({
      current: imgArr[index], // 当前显示图片的http链接
      urls: imgArr // 需要预览的图片http链接列表
    })
  },





  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
})