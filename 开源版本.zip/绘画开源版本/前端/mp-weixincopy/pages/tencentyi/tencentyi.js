// pages/myinfo/myinfo.js
var util = require('../../utils/util.js')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    text:'',
    target_id:'',
    target:'en',
    reslut:'',
  },
  audioPlay: function () {
    this.setData({
     action: {
      method: 'play'
     }
    });
   },
   audioPause: function () {
    this.setData({
     action: {
      method: 'pause'
     }
    });
   },
   audioPlaybackRateSpeedUp: function () {
    this.setData({
     action: {
      method: 'setPlaybackRate',
      data: 2//加快速度
     }
    });
   },
   audioPlaybackRateSlowDown: function () {
    this.setData({
     action: {
      method: 'setPlaybackRate',
      data: 0.5//小于零放慢速度
     }
    });
   },
   audio14: function () {
    this.setData({
     action: {
      method: 'setCurrentTime',
      data: 14
     }
    });
   },
   audioStart: function () {
    this.setData({
     action: {
      method: 'setCurrentTime',
      data: 0
     }
    });
   },

  //复制结果
  copynow:function(e){
    wx.setClipboardData({
        data: e.currentTarget.dataset.text,
        success: function (res) {
          wx.getClipboardData({
            success: function (res) {
              wx.showToast({
                title: '复制成功',
                icon: 'none',
                duration: 2000
             })
            }
          })
        }
      })
  },



  //输入要求
  settext: function (e) {
    this.setData({
        text: e.detail.value
    })
  },



  //查询
  submit:function(){
    if (this.data.text == "" ){
      wx.showToast({
        title: '请输入要求',
        icon:'none'
      })
      return
    }
    var that = this
    wx.showLoading({
        title: '翻译中...',
      })
    wx.request({
      url: 'https://www.wanfankeji19.xyz/copynew/public/api/wanfanai/tencent_translate',
      method: 'POST',
      header: {// 设置请求的 header  
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        text:that.data.text,
        target:that.data.target,
      },
      success: function (res) {
        wx.hideLoading()
        if(res.data.code!=200){
            wx.showToast({
                title: '网络延迟较高,请稍后重试哦~',
                icon: 'none',
                duration: 2000
            })
        }else{
            that.setData({
                reslut:res.data.targetText,
            })
           
        }
      },
      fail: function (res) {
        wx.showToast({
          title: '请求失败',
        })
      },
    })
  },


  //获取语言类型
  getlanguage:function(){
    var that = this
    wx.showLoading({
        title: '加载中...',
      })
    wx.request({
      url: 'https://www.wanfankeji19.xyz/copynew/public/api/wanfanai/getlanguage',
      method: 'POST',
      header: {// 设置请求的 header  
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        
      },
      success: function (res) {
        wx.hideLoading()
          that.setData({
            language:res.data,
          })
      },
      fail: function (res) {
        wx.showToast({
          title: '请求失败',
        })
      },
    })
  },

  //文字转语音
  text_to_speech:function(e) {
    var that = this;
    wx.showLoading({
      title: '加载中...',
      mask: true
    })
    wx.request({
      url: 'https://www.wanfankeji19.xyz/copynew/public/api/wanfanai/text_to_speech',
      method: 'post',
      header: {// 设置请求的 header  
        'content-type': 'application/x-www-form-urlencoded'
      },
      data: {
        text:that.data.reslut
      },
      success: function (res) {
        wx.hideLoading()
        that.setData({
          src:res.data,
        })
        // console.log(that.data.srcMic);
        // that.audioPlay()
         //播放通知
         that.setData({
            src: res.data,
          })
          console.log(that.data.src);
          that.audioCtx.play()
      },
      fail: function (res) {
        wx.showToast({
          title: '请求失败',
        })
      },
    })
  },
   //选择语言
   bindPickerChange_job: function(e) {
    var that = this
    that.setData({
        target_id: that.data.language[e.detail.value]['id'],
        target_name: that.data.language[e.detail.value]['name'],
        target: that.data.language[e.detail.value]['code']
    })
  },

  //播放语音
  audioPlay: function () {
    this.audioCtx.play()
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      this.getlanguage()
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    this.audioCtx = wx.createAudioContext('myAudio')
  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },
})