"use strict";
const config = {
  // 域名
  apiurl: "https://func-ifc-ai-cpnnyxiwmc.cn-chengdu.fcapp.run",
  // 联系人微信
  contactperson: "zt19989022"
};
exports.config = config;
